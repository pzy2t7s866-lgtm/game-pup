# Stonk City Telegram high scores

The static game submits a player's score at game over. This API verifies Telegram Mini App `initData` with the bot token and stores the player's highest score per mode in Postgres. It also exposes public top-10 lists for City and Space. The bot token belongs **only** in the Render web service environment, never in the game HTML or GitHub.

## Set up

1. In @BotFather, select the bot you want to launch Stonk City. Under **Bot Settings → Configure Mini App**, enable the main Mini App and set its URL to `https://stonk-city-v2-game-pup.onrender.com/`. Use the same bot for `TELEGRAM_BOT_TOKEN` below. A plain website link does not supply authenticated Mini App data.
2. Create a persistent Render Postgres database in the same workspace and region as the API web service. Do not use Free Postgres for permanent scores: the Free database expires after 30 days.
3. Upload the accompanying `stonk-leaderboard-api.zip` to the repository root. Create a new Render Web Service from this repository with **Root Directory** empty, **Build Command** `unzip -o stonk-leaderboard-api.zip -d api && cd api && npm install`, **Start Command** `cd api && npm start`, and a Node runtime. Name it `stonk-city-scores` if available; otherwise change the `scoreApi` URL in the updated `stonk-city-v2.html` to its actual public URL.
4. Add environment variables to the API service: `DATABASE_URL` = the database's **internal** connection URL; `TELEGRAM_BOT_TOKEN` = the bot's token; `GAME_ORIGIN` = `https://stonk-city-v2-game-pup.onrender.com`. Never share the token or database URL in chat or a commit.
5. Deploy the API first. Verify `/health` returns `{"ok":true}`. Then deploy the updated static game. Open the game from the bot's Mini App button in Telegram, finish a round, and check the City or Space high-score screen.

## Behavior and limits

- Direct browser play remains available, but can only view scores; scoring requires a verified Telegram Mini App launch.
- One best score per Telegram user is kept for each game mode. In-game high scores show 10 players. Telegram does not automatically post these scores to a channel.
- The browser runs the game and sends its final score. A modified client can claim an unearned score. For prizes or competitive leaderboards, move scoring to a server-verified game design.
- Avoid changing the bot token without updating the API service. Previously opened Mini App sessions expire after 24 hours; reopening refreshes the session.
