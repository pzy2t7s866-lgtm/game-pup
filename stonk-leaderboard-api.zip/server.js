import http from 'node:http';
import crypto from 'node:crypto';
import {Pool} from 'pg';

const token = process.env.TELEGRAM_BOT_TOKEN;
const databaseUrl = process.env.DATABASE_URL;
const origin = process.env.GAME_ORIGIN || 'https://stonk-city-v2-game-pup.onrender.com';
if (!token || !databaseUrl) throw new Error('TELEGRAM_BOT_TOKEN and DATABASE_URL are required');
const pool = new Pool({connectionString: databaseUrl, max: 5});
await pool.query(`CREATE TABLE IF NOT EXISTS stonk_scores (
  telegram_id BIGINT NOT NULL,
  mode TEXT NOT NULL CHECK (mode IN ('city', 'space')),
  display_name TEXT NOT NULL,
  score INTEGER NOT NULL CHECK (score >= 0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (telegram_id, mode)
)`);

function validate(initData) {
  if (typeof initData !== 'string' || initData.length > 8192) return null;
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  if (!hash || !/^[a-f0-9]{64}$/i.test(hash)) return null;
  params.delete('hash');
  const check = [...params.entries()].sort(([a],[b]) => a < b ? -1 : a > b ? 1 : 0)
    .map(([key,value]) => `${key}=${value}`).join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(token).digest();
  const expected = crypto.createHmac('sha256', secret).update(check).digest();
  if (!crypto.timingSafeEqual(expected, Buffer.from(hash, 'hex'))) return null;
  const age = Math.floor(Date.now()/1000) - Number(params.get('auth_date'));
  if (!Number.isFinite(age) || age < -60 || age > 86400) return null;
  try {
    const user = JSON.parse(params.get('user'));
    if (!Number.isSafeInteger(user.id) || user.id <= 0) return null;
    return {id: user.id, name: String(user.first_name || user.username || 'Player').slice(0, 50)};
  } catch { return null; }
}

function respond(res, status, data, requestOrigin) {
  res.writeHead(status, {
    'Content-Type':'application/json; charset=utf-8',
    'Cache-Control':'no-store',
    'Access-Control-Allow-Origin': requestOrigin === origin ? origin : 'null',
    'Vary':'Origin',
    'Access-Control-Allow-Methods':'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers':'Content-Type, X-Telegram-Init-Data'
  });
  res.end(JSON.stringify(data));
}

const server = http.createServer(async (req,res) => {
  const requestOrigin = req.headers.origin;
  if (requestOrigin && requestOrigin !== origin) return respond(res,403,{error:'Origin not allowed'},requestOrigin);
  if (req.method === 'OPTIONS') return respond(res,204,{},requestOrigin);
  const pathname = new URL(req.url, 'http://localhost').pathname;
  try {
    if (pathname === '/health' && req.method === 'GET') return respond(res,200,{ok:true},requestOrigin);
    if (pathname === '/api/leaderboard' && req.method === 'GET') {
      const mode = new URL(req.url,'http://localhost').searchParams.get('mode');
      if (!['city','space'].includes(mode)) return respond(res,400,{error:'Invalid mode'},requestOrigin);
      const {rows} = await pool.query('SELECT display_name, score FROM stonk_scores WHERE mode=$1 ORDER BY score DESC, updated_at ASC LIMIT 10',[mode]);
      return respond(res,200,{scores:rows},requestOrigin);
    }
    if (pathname === '/api/score' && req.method === 'POST') {
      const user = validate(req.headers['x-telegram-init-data']);
      if (!user) return respond(res,401,{error:'Open the game from its Telegram Mini App button to save scores.'},requestOrigin);
      let raw = '';
      for await (const chunk of req) {
        raw += chunk;
        if (raw.length > 2048) return respond(res,413,{error:'Request too large'},requestOrigin);
      }
      let body;
      try { body=JSON.parse(raw); } catch { return respond(res,400,{error:'Invalid JSON'},requestOrigin); }
      if (!['city','space'].includes(body.mode) || !Number.isInteger(body.score) || body.score<0 || body.score>10000000)
        return respond(res,400,{error:'Invalid score'},requestOrigin);
      const {rows} = await pool.query(`INSERT INTO stonk_scores (telegram_id,mode,display_name,score)
        VALUES ($1,$2,$3,$4) ON CONFLICT (telegram_id,mode) DO UPDATE SET
        display_name=EXCLUDED.display_name, score=GREATEST(stonk_scores.score,EXCLUDED.score),
        updated_at=CASE WHEN EXCLUDED.score>stonk_scores.score THEN now() ELSE stonk_scores.updated_at END
        RETURNING score`,[user.id,body.mode,user.name,body.score]);
      return respond(res,200,{best:rows[0].score},requestOrigin);
    }
    return respond(res,404,{error:'Not found'},requestOrigin);
  } catch (error) {
    console.error(error);
    return respond(res,500,{error:'Score service unavailable'},requestOrigin);
  }
});
server.listen(Number(process.env.PORT)||3000, '0.0.0.0');
