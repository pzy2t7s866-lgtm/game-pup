# GAME PUP — Telegram Mini App

This is a deployable starter for GAME PUP:
- 30-second tap game
- Your uploaded cyber-dog artwork
- Combo scoring
- Bone counter
- Cyber boost power meter
- Telegram WebApp integration
- Telegram user signature validation on the server
- Persistent SQLite leaderboard
- Share-score button

## Run locally

1. Install Node.js 20+.
2. In this folder:
   npm install
3. Set your Telegram bot token:
   macOS/Linux:
   export TELEGRAM_BOT_TOKEN="123456:ABC..."
   Windows PowerShell:
   $env:TELEGRAM_BOT_TOKEN="123456:ABC..."
4. Run:
   npm start
5. Open http://localhost:3000

Telegram Mini Apps require an HTTPS URL for real Telegram use.

## Put it in Telegram

1. Create a bot with @BotFather.
2. Deploy this project to an HTTPS host such as Render, Railway, Fly.io, or similar.
3. Add environment variable:
   TELEGRAM_BOT_TOKEN = your BotFather token
4. In @BotFather, configure your bot's Menu Button / Web App URL to your deployed HTTPS URL.
5. Add the bot to your Telegram channel/group as appropriate.
6. Post a link/button to open the bot or Mini App.

## Production notes

- The server validates Telegram initData before accepting scores.
- For a high-traffic launch, move from SQLite to Postgres.
- To reduce cheating further, add server-issued game sessions and server-side score validation.
- Add rate limiting before a public launch.