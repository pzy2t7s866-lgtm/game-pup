# GAME PUP: Bone Run + Sky Run

A phone-friendly maze chase starring the fluffy white pup with the red GME visor.
Swipe the maze or use the arrow buttons to collect bones, dodge moving cats, grab
power bones to chase them, and advance through faster levels. Sound is optional.

Sky Run is a second game at `/sky-run.html`. A transparent full-body cyber pup
automatically runs across rooftops. Tap the game or JUMP button once to jump,
then again in midair for a double jump. Collect bones, avoid drones, use shields,
and stay on the platforms. Bone Run links to Sky Run at the top of its page.

Both games work in a normal browser and store separate personal best scores there.
Bone Run can also submit scores to the server's Telegram leaderboard after
`TELEGRAM_BOT_TOKEN` is set privately on the server. Sky Run does not use that
leaderboard, so scores from different games never mix.

## Run locally

Use Node 22, run `npm install`, then `npm start`. Visit `http://localhost:3000`.

## Update the existing Render service

Render currently deploys from `GAME-PUP-Telegram-App.zip` in the GitHub repo.
Replace that archive with the updated one from this project on the `main` branch.
The current Render build command extracts the archive and installs Express 4;
its start command runs `npm start` in the extracted `app` folder. Render should
use `NODE_VERSION=22.16.0`.

For Telegram score saving, put `TELEGRAM_BOT_TOKEN` in the service's Environment
settings, then set the Mini App URL to `https://game-pup.onrender.com` in
@BotFather. Never put the token in GitHub or the game code.

Free Render services lose local SQLite leaderboard scores when they spin down,
restart, or redeploy. Use persistent storage before a public leaderboard launch.
