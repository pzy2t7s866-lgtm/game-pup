# GAME PUP: Bone Run

A phone-friendly maze chase starring the fluffy white pup with the red GME visor.
Swipe the maze or use the arrow buttons to collect bones, dodge moving cats, grab
power bones to chase them, and advance through faster levels. Sound is optional.

The game works in a normal browser. A personal best is stored in that browser.
When opened from the Telegram bot, it can also submit a score to the server's
leaderboard after `TELEGRAM_BOT_TOKEN` is set privately on the server.

## Run locally

Use Node 22, run `npm install`, then `npm start`. Visit `http://localhost:3000`.

## Update the existing Render service

Render currently deploys from `GAME-PUP-Telegram-App.zip` in the GitHub repo.
Replace that archive with the updated one from this project on the `main` branch.
The current Render build command extracts the archive and installs Express 4;
its start command runs `npm start` in the extracted `app` folder. Render should
use `NODE_VERSION=22.16.0`.

For Telegram score saving, put `TELEGRAM_BOT_TOKEN` in the service's Environment
settings, then set the Mini App URL to `https://game-pup.onrender.com` in
@BotFather. Never put the token in GitHub or the game code.

Free Render services lose local SQLite leaderboard scores when they spin down,
restart, or redeploy. Use persistent storage before a public leaderboard launch.
