const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
  try { tg.setHeaderColor("#0d0f12"); tg.setBackgroundColor("#0d0f12"); } catch {}
}

const $ = (s) => document.querySelector(s);
const pup = $("#pup"), arena = $("#arena"), startBtn = $("#startBtn"), shareBtn = $("#shareBtn");
const scoreEl = $("#score"), timeEl = $("#time"), comboEl = $("#combo"), bonesEl = $("#bones");
const powerEl = $("#power"), bestEl = $("#bestScore"), msg = $("#message"), intro = $("#intro");
const board = $("#leaderboardList"), refreshBtn = $("#refreshBtn");

let score = 0, timeLeft = 30, combo = 1, bones = 0, power = 0, best = 0, lastTap = 0;
let playing = false, timer = null;

function render() {
  scoreEl.textContent = score;
  timeEl.textContent = timeLeft;
  comboEl.textContent = "x" + combo;
  bonesEl.textContent = bones;
  powerEl.textContent = power + "%";
  bestEl.textContent = best;
}

function movePup() {
  pup.style.left = (16 + Math.random() * 68) + "%";
  pup.style.top = (20 + Math.random() * 62) + "%";
}

function burst(text) {
  const el = document.createElement("div");
  el.className = "float";
  el.textContent = text;
  el.style.left = pup.style.left;
  el.style.top = pup.style.top;
  arena.appendChild(el);
  setTimeout(() => el.remove(), 650);
}

function tapPup() {
  if (!playing) return;
  const now = Date.now();
  combo = now - lastTap < 650 ? Math.min(5, combo + 1) : 1;
  lastTap = now;
  bones++;
  score += combo;
  power = Math.min(100, power + 8);

  if (power >= 100) {
    score += 10;
    power = 0;
    msg.textContent = "⚡ CYBER BOOST +10!";
    try { tg?.HapticFeedback?.notificationOccurred("success"); } catch {}
  } else {
    try { tg?.HapticFeedback?.impactOccurred("light"); } catch {}
  }

  best = Math.max(best, score);
  burst("🦴 +" + combo);
  movePup();
  render();
}

async function submitScore() {
  if (!tg?.initData) {
    msg.textContent = "Open GAME PUP inside Telegram to save leaderboard scores.";
    return;
  }
  try {
    const res = await fetch("/api/score", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Telegram-Init-Data": tg.initData
      },
      body: JSON.stringify({ score, bones })
    });
    if (!res.ok) throw new Error("Score save failed");
    await loadLeaderboard();
  } catch {
    msg.textContent = "Score could not be saved. Try again.";
  }
}

async function finish() {
  playing = false;
  clearInterval(timer);
  timer = null;
  pup.disabled = true;
  startBtn.disabled = false;
  startBtn.textContent = "PLAY AGAIN";
  combo = 1;
  msg.textContent = `ROUND OVER — ${score} points • ${bones} bones`;
  render();
  await submitScore();
}

function play() {
  clearInterval(timer);
  score = 0; timeLeft = 30; combo = 1; bones = 0; power = 0; lastTap = 0;
  playing = true;
  intro.hidden = true;
  pup.disabled = false;
  startBtn.disabled = true;
  startBtn.textContent = "GAME ON";
  msg.textContent = "GO GAME PUP!";
  movePup();
  render();
  timer = setInterval(() => {
    timeLeft--;
    if (timeLeft <= 0) {
      timeLeft = 0;
      render();
      finish();
    } else render();
  }, 1000);
}

async function loadLeaderboard() {
  try {
    const res = await fetch("/api/leaderboard");
    const rows = await res.json();
    board.innerHTML = "";
    if (!rows.length) {
      board.innerHTML = "<li><span>No scores yet — be first!</span><strong>—</strong></li>";
      return;
    }
    rows.slice(0, 10).forEach((row, i) => {
      const li = document.createElement("li");
      const name = row.username ? "@" + row.username : (row.first_name || "Player");
      li.innerHTML = `<span>${i + 1}. ${escapeHtml(name)}</span><strong>${row.best_score}</strong>`;
      board.appendChild(li);
    });
  } catch {
    board.innerHTML = "<li><span>Leaderboard unavailable</span><strong>—</strong></li>";
  }
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

function shareScore() {
  const text = `I scored ${score} points in GAME PUP 🐶⚡ Can you beat me?`;
  const url = location.href;
  const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
  if (tg?.openTelegramLink) tg.openTelegramLink(shareUrl);
  else window.open(shareUrl, "_blank", "noopener,noreferrer");
}

pup.addEventListener("click", tapPup);
startBtn.addEventListener("click", play);
shareBtn.addEventListener("click", shareScore);
refreshBtn.addEventListener("click", loadLeaderboard);

render();
loadLeaderboard();