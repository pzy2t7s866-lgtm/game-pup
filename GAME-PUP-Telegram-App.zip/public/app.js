const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
  try { tg.setHeaderColor('#130e21'); tg.setBackgroundColor('#130e21'); } catch {}
}

const $ = (selector) => document.querySelector(selector);
const canvas = $('#maze');
const ctx = canvas.getContext('2d');
const pupImage = new Image();
pupImage.src = '/assets/pup-cutout.png';
pupImage.onload = draw;
const W = 17, H = 21, T = 24;
const vectors = { left: [-1, 0], up: [0, -1], down: [0, 1], right: [1, 0] };
const directions = Object.keys(vectors);
const key = (x, y) => `${x},${y}`;
let maze, bones, powers, pup, cats, score = 0, best = 0, level = 1, lives = 3;
let direction = 'right', queued = 'right', powered = 0, immune = 0, ticks = 0;
let timer = null, mode = 'ready', muted = false, audio;

try { best = Number(localStorage.getItem('game-pup-best')) || 0; muted = localStorage.getItem('game-pup-muted') === 'yes'; } catch {}
$('#soundBtn').textContent = muted ? '♩' : '♪';
$('#soundBtn').setAttribute('aria-label', muted ? 'Turn sound on' : 'Mute sound');

function sound(frequency = 440, duration = .07, waveform = 'sine') {
  if (muted) return;
  try {
    audio ||= new (window.AudioContext || window.webkitAudioContext)();
    if (audio.state === 'suspended') audio.resume();
    const osc = audio.createOscillator(), gain = audio.createGain();
    osc.type = waveform;
    osc.frequency.setValueAtTime(frequency, audio.currentTime);
    osc.frequency.exponentialRampToValueAtTime(Math.max(70, frequency * .68), audio.currentTime + duration);
    gain.gain.setValueAtTime(.045, audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001, audio.currentTime + duration);
    osc.connect(gain).connect(audio.destination);
    osc.start(); osc.stop(audio.currentTime + duration);
  } catch {}
}

function makeMaze() {
  maze = Array.from({length: H}, () => Array(W).fill(1));
  const stack = [[1, 1]];
  maze[1][1] = 0;
  while (stack.length) {
    const [x, y] = stack[stack.length - 1];
    const options = directions.map(d => vectors[d]).filter(([dx, dy]) =>
      x + dx * 2 > 0 && x + dx * 2 < W - 1 && y + dy * 2 > 0 && y + dy * 2 < H - 1 &&
      maze[y + dy * 2][x + dx * 2] === 1);
    if (!options.length) { stack.pop(); continue; }
    const [dx, dy] = options[Math.floor(Math.random() * options.length)];
    maze[y + dy][x + dx] = 0;
    maze[y + dy * 2][x + dx * 2] = 0;
    stack.push([x + dx * 2, y + dy * 2]);
  }
  // Make the maze less of a single-path puzzle and give the cats routes to flank Pup.
  let openings = 0;
  while (openings < 28) {
    const x = 1 + Math.floor(Math.random() * (W - 2));
    const y = 1 + Math.floor(Math.random() * (H - 2));
    if (!maze[y][x]) continue;
    const horizontal = !maze[y][x - 1] && !maze[y][x + 1];
    const vertical = !maze[y - 1][x] && !maze[y + 1][x];
    if (horizontal || vertical) { maze[y][x] = 0; openings++; }
  }
  bones = new Set(); powers = new Set();
  for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
    if (!maze[y][x]) bones.add(key(x, y));
  }
  bones.delete(key(1, 1));
  const targets = [[W-2, 1], [1, H-2], [W-2, H-2]];
  for (const [x, y] of targets) { const k = key(x, y); if (bones.delete(k)) powers.add(k); }
  // Pick far-away open cells for the three cat homes.
  const distances = new Map([[key(1,1), 0]]), queue = [[1,1]];
  for (let i = 0; i < queue.length; i++) {
    const [x,y] = queue[i], dist = distances.get(key(x,y));
    for (const [dx,dy] of Object.values(vectors)) {
      const nx=x+dx, ny=y+dy, k=key(nx,ny);
      if (maze[ny]?.[nx] === 0 && !distances.has(k)) { distances.set(k,dist+1); queue.push([nx,ny]); }
    }
  }
  const far = [...distances.entries()].sort((a,b) => b[1]-a[1]).slice(0,24);
  const homes = [far[0], far[8], far[16]].map(([position]) => position.split(',').map(Number));
  cats = homes.map(([x,y],i) => ({x,y,home:{x,y},previous:null,color:['#ff637a','#66d5ef','#ffb55e'][i]}));
  homes.forEach(([x,y]) => { bones.delete(key(x,y)); powers.delete(key(x,y)); });
  pup = {x:1,y:1}; direction = 'right'; queued = 'right'; powered = 0; immune = 12; ticks = 0;
}

function updateHud() {
  $('#score').textContent = score.toLocaleString();
  $('#best').textContent = best.toLocaleString();
  $('#level').textContent = level;
  $('#lives').textContent = Array(lives).fill('♥').join(' ') || '—';
}
function setStatus(message) { $('#status').textContent = message; }
function addScore(points) {
  score += points;
  if (score > best) {
    best = score;
    try { localStorage.setItem('game-pup-best', String(best)); } catch {}
  }
  updateHud();
}
function show(title, message, button) {
  $('#overlayTitle').textContent = title;
  $('#overlayText').textContent = message;
  $('#startBtn').firstChild.textContent = button + ' ';
  $('#overlay').hidden = false;
}
function stop() { clearInterval(timer); timer = null; }
function run() {
  $('#overlay').hidden = true;
  mode = 'playing'; $('#pauseBtn').disabled = false; $('#pauseBtn').textContent = 'Ⅱ Pause';
  stop(); timer = setInterval(step, Math.max(105, 185 - (level - 1) * 10));
  draw();
}
function start() {
  if (mode === 'gameover') { score = 0; lives = 3; level = 1; makeMaze(); }
  if (mode === 'ready') makeMaze();
  updateHud(); setStatus('Catch every bone!'); sound(620,.13);
  run();
}
function pause() {
  if (mode !== 'playing') return;
  mode = 'paused'; stop(); $('#pauseBtn').textContent = '▶ Resume';
  show('Pup is taking a breather', 'Swipe through the maze, grab every bone and keep those cats away.', 'RESUME');
}

function canMove(x,y,d) {
  const [dx,dy] = vectors[d];
  return maze[y+dy]?.[x+dx] === 0;
}
function moveCats() {
  for (const cat of cats) {
    const options = directions.filter(d => canMove(cat.x,cat.y,d));
    if (!options.length) continue;
    const target = powered ? cat.home : pup;
    const ranked = options.map(d => {
      const [dx,dy]=vectors[d], distance=Math.abs(cat.x+dx-target.x)+Math.abs(cat.y+dy-target.y);
      return {d,weight:(powered ? -distance : distance) + Math.random()*3 + (d===cat.previous ? 1.7 : 0)};
    }).sort((a,b) => a.weight-b.weight);
    const choice = Math.random() < .20 ? options[Math.floor(Math.random()*options.length)] : ranked[0].d;
    const [dx,dy]=vectors[choice]; cat.x+=dx; cat.y+=dy;
    cat.previous = ({left:'right',right:'left',up:'down',down:'up'})[choice];
  }
}
function checkCats() {
  for (const cat of cats) {
    if (cat.x !== pup.x || cat.y !== pup.y || immune) continue;
    if (powered) {
      addScore(200); sound(880,.22,'triangle');
      cat.x=cat.home.x; cat.y=cat.home.y;
      setStatus('CAT CAUGHT! +200');
    } else {
      lives--; updateHud(); sound(180,.35,'sawtooth');
      if (lives <= 0) { gameOver(); return true; }
      pup={x:1,y:1}; direction='right'; queued='right'; immune=14;
      cats.forEach(cat => {cat.x=cat.home.x;cat.y=cat.home.y;});
      setStatus('Ouch! Two paws on the ground!');
      return true;
    }
  }
  return false;
}
function step() {
  ticks++; if (powered) powered--; if (immune) immune--;
  if (canMove(pup.x,pup.y,queued)) direction=queued;
  if (canMove(pup.x,pup.y,direction)) {
    const [dx,dy]=vectors[direction]; pup.x+=dx; pup.y+=dy;
  }
  const k=key(pup.x,pup.y);
  if (bones.delete(k)) { addScore(10); if (ticks%2) sound(420+Math.random()*120,.045); }
  if (powers.delete(k)) { powered=60; addScore(50); sound(950,.3,'triangle'); setStatus('POWER PUP! Chase the cats!'); }
  if (checkCats()) { draw(); return; }
  if (ticks % 2 === 0) { moveCats(); if (checkCats()) { draw(); return; } }
  if (bones.size === 0 && powers.size === 0) {
    stop(); mode='level'; level++; makeMaze(); updateHud(); sound(990,.28);
    show('LEVEL CLEARED!', 'New maze, faster cats. Can Pup keep the bone streak going?', 'NEXT LEVEL');
  } else if (powered && ticks%8===0) setStatus(`POWER PUP! ${Math.ceil(powered/6)}s left`);
  draw();
}
async function gameOver() {
  stop(); mode='gameover'; $('#pauseBtn').disabled=true;
  setStatus(`Final score: ${score.toLocaleString()}`);
  show('Run over!', `Pup earned ${score.toLocaleString()} points and reached level ${level}. Ready for another chase?`, 'PLAY AGAIN');
  draw();
  if (!tg?.initData) return;
  try {
    const response=await fetch('/api/score',{method:'POST',headers:{'Content-Type':'application/json','X-Telegram-Init-Data':tg.initData},body:JSON.stringify({score,bones:Math.floor(score/10)})});
    if (response.ok) loadLeaderboard();
  } catch {}
}

function drawBone(x,y,large=false) {
  const px=x*T+T/2, py=y*T+T/2;
  ctx.fillStyle=large?'#72f7db':'#ffd978';
  if (large) {ctx.shadowBlur=16;ctx.shadowColor='#65f9dc';}
  const size=large?4.5:2.6;
  ctx.fillRect(px-size,py-size/2,size*2,size);
  for (const ox of [-size,size]) for (const oy of [-size/2,size/2]) {
    ctx.beginPath();ctx.arc(px+ox,py+oy,size*.55,0,Math.PI*2);ctx.fill();
  }
  ctx.shadowBlur=0;
}
function drawCat(cat) {
  const x=(cat.x+.5)*T,y=(cat.y+.5)*T;
  ctx.save();
  ctx.fillStyle=powered?'#8b9cbd':cat.color;
  ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=powered?4:8;
  ctx.beginPath();ctx.moveTo(x-9,y-5);ctx.lineTo(x-8,y-12);ctx.lineTo(x-2,y-9);ctx.lineTo(x+2,y-9);ctx.lineTo(x+8,y-12);ctx.lineTo(x+9,y-5);ctx.arc(x,y,9,0,Math.PI);ctx.closePath();ctx.fill();
  ctx.shadowBlur=0;ctx.fillStyle='#fff';
  ctx.beginPath();ctx.arc(x-3,y-1,2.2,0,Math.PI*2);ctx.arc(x+3,y-1,2.2,0,Math.PI*2);ctx.fill();
  ctx.fillStyle='#241126';ctx.beginPath();ctx.arc(x-3,y-1,1,0,Math.PI*2);ctx.arc(x+3,y-1,1,0,Math.PI*2);ctx.fill();
  ctx.restore();
}
function draw() {
  if (!maze || !ctx) return;
  ctx.fillStyle='#100f25';ctx.fillRect(0,0,W*T,H*T);
  for (let y=0;y<H;y++) for (let x=0;x<W;x++) {
    if (maze[y][x]) {
      ctx.fillStyle='#45254f';ctx.fillRect(x*T+1,y*T+1,T-2,T-2);
      ctx.strokeStyle='#a04473';ctx.lineWidth=.8;ctx.strokeRect(x*T+2,y*T+2,T-4,T-4);
    } else {
      ctx.fillStyle=(x+y)%2?'#181429':'#1b162e';ctx.fillRect(x*T,y*T,T,T);
    }
  }
  for (const k of bones) {const [x,y]=k.split(',').map(Number);drawBone(x,y);}
  for (const k of powers) {const [x,y]=k.split(',').map(Number);drawBone(x,y,true);}
  cats.forEach(drawCat);
  if (!immune || ticks%3) {
    const x=(pup.x+.5)*T,y=(pup.y+.5)*T;
    ctx.fillStyle=powered?'#74ffe3':'#ffcb77';ctx.beginPath();ctx.arc(x,y,11,0,Math.PI*2);ctx.fill();
    if (pupImage.complete && pupImage.naturalWidth) ctx.drawImage(pupImage,x-19,y-19,38,38);
    else {ctx.fillStyle='#fff';ctx.font='19px sans-serif';ctx.fillText('🐶',x-12,y+7);}
  }
}
async function loadLeaderboard() {
  const board=$('#leaderboardList');
  try {
    const response=await fetch('/api/leaderboard');
    if (!response.ok) throw new Error('leaderboard');
    const rows=await response.json();board.replaceChildren();
    if (!rows.length) {const li=document.createElement('li');li.textContent='No saved scores yet. Be first!';board.append(li);return;}
    rows.slice(0,8).forEach((row,i)=>{
      const li=document.createElement('li'),name=document.createElement('span'),points=document.createElement('strong');
      name.textContent=`${i+1}. ${row.username?'@'+row.username:row.first_name||'Player'}`;
      points.textContent=Number(row.best_score).toLocaleString();li.append(name,points);board.append(li);
    });
  } catch {board.replaceChildren();const li=document.createElement('li');li.textContent='Leaderboard unavailable';board.append(li);}
}

$('#startBtn').addEventListener('click',start);
$('#pauseBtn').addEventListener('click',()=>mode==='paused'?start():pause());
$('#soundBtn').addEventListener('click',()=>{muted=!muted;$('#soundBtn').textContent=muted?'♩':'♪';$('#soundBtn').setAttribute('aria-label',muted?'Turn sound on':'Mute sound');try{localStorage.setItem('game-pup-muted',muted?'yes':'no');}catch{}});
$('#refreshBtn').addEventListener('click',loadLeaderboard);
$('#shareBtn').addEventListener('click',()=>{
  const text=`I scored ${score.toLocaleString()} in GAME PUP: Bone Run 🐶🦴 Can you beat me?`;
  const url=`https://t.me/share/url?url=${encodeURIComponent(location.href)}&text=${encodeURIComponent(text)}`;
  if (tg?.openTelegramLink) tg.openTelegramLink(url); else window.open(url,'_blank','noopener,noreferrer');
});
function steer(d) {queued=d;if(mode==='playing'){try{tg?.HapticFeedback?.impactOccurred('light');}catch{}}}
document.querySelectorAll('[data-dir]').forEach(button=>button.addEventListener('pointerdown',event=>{event.preventDefault();steer(button.dataset.dir);}));
window.addEventListener('keydown',event=>{
  const map={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'up',ArrowDown:'down',a:'left',d:'right',w:'up',s:'down'};
  if(map[event.key]){event.preventDefault();steer(map[event.key]);}
  if(event.code==='Space'){event.preventDefault();mode==='playing'?pause():mode==='paused'?start():null;}
});
let touchStart;
canvas.addEventListener('pointerdown',event=>{touchStart={x:event.clientX,y:event.clientY};});
canvas.addEventListener('pointerup',event=>{
  if(!touchStart)return;
  const dx=event.clientX-touchStart.x,dy=event.clientY-touchStart.y;touchStart=null;
  if(Math.max(Math.abs(dx),Math.abs(dy))<15)return;
  steer(Math.abs(dx)>Math.abs(dy)?dx>0?'right':'left':dy>0?'down':'up');
});
document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});
makeMaze();updateHud();draw();loadLeaderboard();
