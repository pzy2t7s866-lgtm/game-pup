const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); try { tg.setHeaderColor('#11172b'); tg.setBackgroundColor('#11172b'); } catch {} }
const $ = (s) => document.querySelector(s), canvas = $('#game'), ctx = canvas.getContext('2d');
const sprite = new Image(); sprite.src = '/assets/cyber-pup-cutout.png';
const CW = 420, CH = 590, GRAVITY = 1360, PUP_W = 43, PUP_H = 76;
let platforms, collectibles, drones, pup, checkpoint, lastEnd, lastHeight;
let camera = 0, time = 0, lastFrame = 0, maxX = 0, score = 0, best = 0, bones = 0, lives = 3;
let mode = 'ready', muted = false, audio, shield = 0;
try {best = Number(localStorage.getItem('game-pup-sky-best')) || 0; muted = localStorage.getItem('game-pup-sky-muted') === 'yes';} catch {}
$('#soundBtn').textContent = muted ? '♩' : '♪';

function sound(frequency, duration = .12, type = 'sine') {
  if (muted) return;
  try {
    audio ||= new (window.AudioContext || window.webkitAudioContext)();
    if (audio.state === 'suspended') audio.resume();
    const oscillator = audio.createOscillator(), gain = audio.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, audio.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(80,frequency*.65),audio.currentTime+duration);
    gain.gain.setValueAtTime(.07,audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);
    oscillator.connect(gain).connect(audio.destination);
    oscillator.start(); oscillator.stop(audio.currentTime+duration);
  } catch {}
}
const between = (a,b) => a+Math.random()*(b-a);
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
function platformTop(platform) {
  return platform.y + (platform.moving ? Math.sin(time*1.8+platform.phase)*13 : 0);
}
function addPlatform() {
  const count = platforms.length;
  const gap = between(65, Math.min(108,75+maxX/180));
  const width = between(190,270);
  // Height changes stay within the reach of a normal jump.
  const y = clamp(lastHeight + between(-42,42),395,525);
  const next = {x:lastEnd+gap,y,w:width,moving:count>3&&count%4===0,phase:between(0,6)};
  platforms.push(next);
  for (let x=next.x+55;x<next.x+next.w-24;x+=72) {
    collectibles.push({x,y:y-64,type:'bone',taken:false});
  }
  collectibles.push({x:lastEnd+gap/2,y:Math.min(lastHeight,y)-106,type:'bone',taken:false});
  if (count%6===0) collectibles.push({x:next.x+next.w*.53,y:y-110,type:'shield',taken:false});
  if (count>2&&count%3===0) drones.push({platform:next,x:next.x+next.w*.72,phase:between(0,6)});
  lastEnd=next.x+next.w;lastHeight=y;
}
function resetWorld() {
  platforms=[{x:0,y:520,w:520,moving:false,phase:0}];
  collectibles=[{x:275,y:455,type:'bone',taken:false},{x:385,y:455,type:'bone',taken:false}];
  drones=[];lastEnd=520;lastHeight=520;camera=0;time=0;maxX=0;score=0;bones=0;lives=3;shield=0;
  pup={x:85,y:520-PUP_H,w:PUP_W,h:PUP_H,vy:0,jumps:0,on:platforms[0],lastGround:0,invulnerable:0};
  checkpoint=platforms[0];
  while(lastEnd<1300)addPlatform();
  updateHud();
}
function updateHud() {
  $('#score').textContent=score.toLocaleString();
  $('#bones').textContent=bones;
  $('#best').textContent=best.toLocaleString();
  $('#lives').textContent=Array(lives).fill('♥').join(' ')||'—';
}
function setMessage(message) {$('#message').textContent=message;}
function updateScore() {
  const next=Math.floor(maxX/10)+bones*50;
  if(next!==score) {
    score=next;
    if(score>best) {best=score;try{localStorage.setItem('game-pup-sky-best',String(best));}catch{}}
    updateHud();
  }
}
function overlay(title,text,action) {
  $('#overlayTitle').textContent=title;
  $('#overlayText').textContent=text;
  $('#startBtn').textContent=action;
  $('#overlay').hidden=false;
}
function play() {
  if(mode==='over')resetWorld();
  mode='playing';lastFrame=0;$('#overlay').hidden=true;
  $('#pauseBtn').disabled=false;$('#pauseBtn').textContent='Ⅱ PAUSE';
  setMessage('Tap to jump. Tap again for a double jump!');sound(660,.18);
}
function pause() {
  if(mode!=='playing')return;
  mode='paused';$('#pauseBtn').textContent='▶ RESUME';
  overlay('PAWS FOR A SECOND','The rooftops will wait. Time your jump just before each gap.','RESUME RUN →');
}
function jump() {
  if(mode!=='playing')return;
  const coyote=time-pup.lastGround<.09;
  if(pup.on||coyote&&pup.jumps===0) {
    pup.vy=-550;pup.jumps=1;pup.on=null;
    sound(550,.14,'triangle');setMessage('AIR PUP! Tap again to double jump.');
  } else if(pup.jumps<2) {
    pup.vy=-525;pup.jumps=2;
    sound(810,.17,'triangle');setMessage('DOUBLE JUMP! ⚡');
  }
  try{tg?.HapticFeedback?.impactOccurred('light');}catch{}
}
function loseLife(message) {
  lives--;updateHud();sound(155,.33,'sawtooth');
  if(lives<=0) {
    mode='over';$('#pauseBtn').disabled=true;
    overlay('PUP DOWN, NOT OUT',`You scored ${score.toLocaleString()} and collected ${bones} bones. Run it back?`,'TRY AGAIN →');
    setMessage(`Final score: ${score.toLocaleString()}`);return;
  }
  pup.x=checkpoint.x+Math.min(52,checkpoint.w*.25);
  pup.y=platformTop(checkpoint)-pup.h;pup.vy=0;pup.on=checkpoint;pup.jumps=0;
  pup.invulnerable=2.4;camera=Math.max(0,pup.x-105);
  setMessage(`${message} ${lives} ${lives===1?'life':'lives'} left.`);
  try{tg?.HapticFeedback?.notificationOccurred('warning');}catch{}
}
function update(dt) {
  time+=dt;shield=Math.max(0,shield-dt);pup.invulnerable=Math.max(0,pup.invulnerable-dt);
  const speed=Math.min(265,169+maxX/120);
  const oldBottom=pup.y+pup.h;
  pup.x+=speed*dt;
  if(pup.on) {
    if(pup.x+pup.w*.25>pup.on.x+pup.on.w) {pup.on=null;pup.lastGround=time;}
    else {pup.y=platformTop(pup.on)-pup.h;pup.vy=0;}
  }
  if(!pup.on) {
    pup.vy+=GRAVITY*dt;
    pup.y+=pup.vy*dt;
    if(pup.vy>=0)for(const platform of platforms) {
      const top=platformTop(platform);
      if(oldBottom<=top+12&&pup.y+pup.h>=top&&pup.x+pup.w*.72>platform.x&&pup.x+pup.w*.28<platform.x+platform.w) {
        pup.y=top-pup.h;pup.vy=0;pup.on=platform;pup.jumps=0;pup.lastGround=time;checkpoint=platform;
        sound(280,.045);break;
      }
    }
  } else {pup.lastGround=time;}
  maxX=Math.max(maxX,pup.x);camera=Math.max(0,pup.x-113);
  while(lastEnd<camera+1000)addPlatform();
  platforms=platforms.filter(platform=>platform===checkpoint||platform.x+platform.w>camera-350);
  collectibles=collectibles.filter(item=>!item.taken&&item.x>camera-110);
  drones=drones.filter(drone=>drone.x>camera-130);
  for(const item of collectibles) {
    const dx=item.x-(pup.x+pup.w/2),dy=item.y-(pup.y+pup.h*.5);
    if(dx*dx+dy*dy>37*37)continue;
    item.taken=true;
    if(item.type==='shield') {shield=7;sound(880,.25,'triangle');setMessage('ENERGY SHIELD! 7 seconds of protection.');}
    else {bones++;sound(610,.06);if(bones%5===0)setMessage(`${bones} BONES! Keep going!`);}
  }
  updateScore();
  if(pup.y>CH+90) {loseLife('Missed the platform!');return;}
  for(const drone of drones) {
    if(drone.platform.x+drone.platform.w<camera-120)continue;
    const y=platformTop(drone.platform)-36+Math.sin(time*3+drone.phase)*11;
    if(Math.abs(drone.x-(pup.x+pup.w*.5))<31&&Math.abs(y-(pup.y+pup.h*.52))<39&&pup.invulnerable<=0) {
      if(shield>0) {drone.x=-9999;shield=0;sound(900,.2,'triangle');setMessage('Shield smashed the drone!');}
      else {loseLife('A drone got Pup!');return;}
    }
  }
}
function rounded(x,y,w,h,r) {
  ctx.beginPath();ctx.roundRect(x,y,w,h,r);
}
function bone(x,y,scale=1) {
  ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);ctx.fillStyle='#ffe782';ctx.shadowBlur=12;ctx.shadowColor='#ffcb69';
  ctx.fillRect(-9,-3,18,6);
  for(const xx of [-9,9])for(const yy of [-4,4]){ctx.beginPath();ctx.arc(xx,yy,4,0,Math.PI*2);ctx.fill();}
  ctx.restore();
}
function drawBackground() {
  const gradient=ctx.createLinearGradient(0,0,0,CH);
  gradient.addColorStop(0,'#172340');gradient.addColorStop(.54,'#555384');gradient.addColorStop(1,'#f28f99');
  ctx.fillStyle=gradient;ctx.fillRect(0,0,CW,CH);
  const sunX=325-camera*.012%520;
  ctx.fillStyle='#ffcaad';ctx.shadowColor='#ffcfa7';ctx.shadowBlur=65;ctx.beginPath();ctx.arc(sunX,138,61,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
  for(let i=0;i<12;i++){
    const x=(i*113-camera*.12)%560;if(x<-75)continue;
    const h=56+(i*37)%95;
    ctx.fillStyle=i%2?'#494d7a':'#414571';ctx.fillRect(x,CH-110-h,70+(i%3)*23,h);
    ctx.fillStyle='#ffdcad80';for(let wx=x+14;wx<x+60;wx+=19)for(let wy=CH-103-h+13;wy<CH-112;wy+=24){if((wx+wy+i)%3<2)ctx.fillRect(wx,wy,5,7);}
  }
  ctx.fillStyle='#313258';ctx.fillRect(0,CH-110,CW,110);
  ctx.fillStyle='#201c3d';ctx.fillRect(0,CH-55,CW,55);
}
function drawPlatforms() {
  for(const platform of platforms){
    const x=platform.x-camera,y=platformTop(platform);if(x>CW+30||x+platform.w<-30)continue;
    ctx.fillStyle='#1e314f';rounded(x,y,platform.w,CH-y+100,8);ctx.fill();
    ctx.fillStyle='#63edee';rounded(x,y,platform.w,10,5);ctx.fill();
    ctx.fillStyle='#b8fbf7';ctx.fillRect(x+8,y+1,Math.max(0,platform.w-16),2);
    ctx.fillStyle='#40617c';for(let q=x+18;q<x+platform.w-10;q+=33)ctx.fillRect(q,y+22,12,8);
    if(platform.moving){ctx.fillStyle='#ffd673';ctx.fillRect(x+platform.w/2-19,y+15,38,3);}
  }
}
function drawPup() {
  if(pup.invulnerable>0&&Math.floor(time*10)%2===0)return;
  const x=pup.x-camera, y=pup.y;
  if(shield>0){ctx.strokeStyle='#6ffff4';ctx.lineWidth=3;ctx.shadowBlur=17;ctx.shadowColor='#62faff';ctx.beginPath();ctx.ellipse(x+pup.w/2,y+36,43,55,0,0,Math.PI*2);ctx.stroke();ctx.shadowBlur=0;}
  ctx.save();ctx.translate(x+pup.w/2,y+pup.h/2);
  if(pup.on)ctx.rotate(Math.sin(time*20)*.035);
  else ctx.rotate(clamp(pup.vy/3800,-.15,.19));
  if(sprite.complete&&sprite.naturalWidth)ctx.drawImage(sprite,-55,-60,110,114);
  else {ctx.font='64px sans-serif';ctx.fillText('🐶',-35,23);}
  ctx.restore();
}
function draw() {
  drawBackground();drawPlatforms();
  for(const item of collectibles){if(item.taken||item.x-camera<-30||item.x-camera>CW+30)continue;
    if(item.type==='shield'){
      ctx.fillStyle='#69ffee';ctx.shadowColor='#69ffee';ctx.shadowBlur=15;ctx.beginPath();ctx.arc(item.x-camera,item.y+Math.sin(time*5)*4,13,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
      ctx.fillStyle='#104359';ctx.font='bold 16px sans-serif';ctx.fillText('✦',item.x-camera-8,item.y+6);
    }else bone(item.x-camera,item.y+Math.sin(time*5+item.x)*3,.85);
  }
  for(const drone of drones){const x=drone.x-camera;if(x<-30||x>CW+30)continue;
    const y=platformTop(drone.platform)-36+Math.sin(time*3+drone.phase)*11;
    ctx.fillStyle='#ef4968';ctx.shadowColor='#ff6183';ctx.shadowBlur=14;rounded(x-15,y-14,30,28,7);ctx.fill();ctx.shadowBlur=0;
    ctx.fillStyle='#fff';ctx.fillRect(x-8,y-3,5,5);ctx.fillRect(x+3,y-3,5,5);
    ctx.strokeStyle='#fa8ba2';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x-19,y-14);ctx.lineTo(x+19,y-14);ctx.stroke();
  }
  drawPup();
  ctx.fillStyle='#ffffffb8';ctx.font='800 14px sans-serif';ctx.fillText(`DISTANCE ${Math.floor(maxX/10)}m`,15,29);
  if(shield>0){ctx.fillStyle='#78fff0';ctx.fillText(`SHIELD ${Math.ceil(shield)}s`,295,29);}
}
function frame(now) {
  const dt=lastFrame?Math.min(.032,(now-lastFrame)/1000):0;
  lastFrame=now;
  if(mode==='playing')update(dt);
  draw();requestAnimationFrame(frame);
}
$('#startBtn').addEventListener('click',play);
$('#pauseBtn').addEventListener('click',()=>mode==='paused'?play():pause());
$('#jumpBtn').addEventListener('pointerdown',e=>{e.preventDefault();jump();});
canvas.addEventListener('pointerdown',e=>{e.preventDefault();jump();});
window.addEventListener('keydown',e=>{
  if(['Space','ArrowUp','KeyW'].includes(e.code)){e.preventDefault();if(!e.repeat)jump();}
  if(e.code==='KeyP'){e.preventDefault();mode==='playing'?pause():mode==='paused'?play():null;}
});
$('#soundBtn').addEventListener('click',()=>{muted=!muted;$('#soundBtn').textContent=muted?'♩':'♪';$('#soundBtn').setAttribute('aria-label',muted?'Turn sound on':'Mute sound');try{localStorage.setItem('game-pup-sky-muted',muted?'yes':'no');}catch{}});
$('#shareBtn').addEventListener('click',()=>{
  const url=`https://t.me/share/url?url=${encodeURIComponent(location.href)}&text=${encodeURIComponent(`I ran ${score.toLocaleString()} points in GAME PUP: Sky Run 🐶⚡ Can you beat me?`)}`;
  if(tg?.openTelegramLink)tg.openTelegramLink(url);else window.open(url,'_blank','noopener,noreferrer');
});
document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});
resetWorld();requestAnimationFrame(frame);
