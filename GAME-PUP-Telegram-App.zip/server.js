import express from "express";
import Database from "better-sqlite3";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";

app.use(express.json({ limit: "64kb" }));
app.use(express.static(path.join(__dirname, "public")));

const db = new Database("game-pup.db");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS players (
  telegram_id TEXT PRIMARY KEY,
  username TEXT,
  first_name TEXT,
  best_score INTEGER NOT NULL DEFAULT 0,
  total_bones INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

function validateTelegramInitData(initData) {
  if (!BOT_TOKEN) return { ok: false, reason: "Server missing TELEGRAM_BOT_TOKEN" };
  if (!initData) return { ok: false, reason: "Missing Telegram init data" };

  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return { ok: false, reason: "Missing hash" };

  params.delete("hash");
  const pairs = [...params.entries()]
    .map(([k, v]) => `${k}=${v}`)
    .sort();
  const dataCheckString = pairs.join("\n");

  const secretKey = crypto.createHmac("sha256", "WebAppData")
    .update(BOT_TOKEN)
    .digest();

  const calculatedHash = crypto.createHmac("sha256", secretKey)
    .update(dataCheckString)
    .digest("hex");

  if (!/^[a-f0-9]{64}$/i.test(hash) ||
      !crypto.timingSafeEqual(Buffer.from(calculatedHash, "hex"), Buffer.from(hash, "hex"))) {
    return { ok: false, reason: "Invalid Telegram signature" };
  }

  const authDate = Number(params.get("auth_date") || 0);
  if (!authDate || (Date.now() / 1000 - authDate) > 86400) {
    return { ok: false, reason: "Telegram login expired" };
  }

  let user = null;
  try { user = JSON.parse(params.get("user") || "null"); } catch {}
  if (!user?.id) return { ok: false, reason: "Telegram user missing" };

  return { ok: true, user };
}

function requireTelegram(req, res, next) {
  const initData = req.get("X-Telegram-Init-Data") || "";
  const auth = validateTelegramInitData(initData);
  if (!auth.ok) return res.status(401).json({ error: auth.reason });
  req.telegramUser = auth.user;
  next();
}

app.get("/api/leaderboard", (_req, res) => {
  const rows = db.prepare(`
    SELECT telegram_id, username, first_name, best_score
    FROM players
    ORDER BY best_score DESC, updated_at ASC
    LIMIT 25
  `).all();
  res.json(rows);
});

app.post("/api/score", requireTelegram, (req, res) => {
  const user = req.telegramUser;
  const score = Math.max(0, Math.min(100000, Number.parseInt(req.body.score, 10) || 0));
  const bones = Math.max(0, Math.min(100000, Number.parseInt(req.body.bones, 10) || 0));

  const current = db.prepare("SELECT * FROM players WHERE telegram_id=?").get(String(user.id));
  if (!current) {
    db.prepare(`
      INSERT INTO players (telegram_id, username, first_name, best_score, total_bones)
      VALUES (?, ?, ?, ?, ?)
    `).run(String(user.id), user.username || "", user.first_name || "Player", score, bones);
  } else {
    db.prepare(`
      UPDATE players
      SET username=?, first_name=?,
          best_score=MAX(best_score, ?),
          total_bones=total_bones + ?,
          updated_at=CURRENT_TIMESTAMP
      WHERE telegram_id=?
    `).run(user.username || "", user.first_name || "Player", score, bones, String(user.id));
  }

  const player = db.prepare("SELECT * FROM players WHERE telegram_id=?").get(String(user.id));
  res.json(player);
});

app.use((_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => console.log(`GAME PUP running on port ${PORT}`));
